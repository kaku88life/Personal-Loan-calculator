// Main Application Logic for Chrome Extension

// Chart instances
let paymentChart = null;
let balanceChart = null;

// Current calculation results
let currentResults = null;
let currentSummary = null;

// Theme settings
const themes = ['light', 'dark', 'night'];
const themeIcons = { light: '🌤️', dark: '🌙', night: '🌃' };
let currentThemeIndex = 0;

// Default loan terms by type (in years)
const defaultLoanTerms = {
    mortgage: 30,
    car: 5,
    personal: 5,
    other: 10
};

// Default loan ratios by type (in %)
const defaultLoanRatios = {
    mortgage: 80,
    car: 100,
    personal: 100,
    other: 80
};

// DOM Elements
const elements = {
    // Controls
    languageSelect: document.getElementById('languageSelect'),
    themeToggle: document.getElementById('themeToggle'),
    themeIcon: document.getElementById('themeIcon'),
    currencySelect: document.getElementById('currencySelect'),
    fontSizeSelect: document.getElementById('fontSizeSelect'),

    // Inputs
    loanTypeSelect: document.getElementById('loanTypeSelect'),
    customLoanType: document.getElementById('customLoanType'),
    loanAmount: document.getElementById('loanAmount'),
    loanRatio: document.getElementById('loanRatio'),
    loanTerm: document.getElementById('loanTerm'),
    gracePeriod: document.getElementById('gracePeriod'),
    gracePeriodToggle: document.getElementById('gracePeriodToggle'),
    gracePeriodInputs: document.getElementById('gracePeriodInputs'),
    gracePeriodUnit: document.getElementById('gracePeriodUnit'),
    interestRate: document.getElementById('interestRate'),
    paymentMethod: document.getElementById('paymentMethod'),
    currencyUnit: document.getElementById('currencyUnit'),

    // Costs
    addCostBtn: document.getElementById('addCostBtn'),
    costsContainer: document.getElementById('costsContainer'),
    totalCostsValue: document.getElementById('totalCostsValue'),

    // Reset
    resetBtn: document.getElementById('resetBtn'),

    // Calculate
    calculateBtn: document.getElementById('calculateBtn'),

    // Results
    resultsSection: document.getElementById('resultsSection'),
    monthlyPaymentValue: document.getElementById('monthlyPaymentValue'),
    totalPaymentValue: document.getElementById('totalPaymentValue'),
    totalInterestValue: document.getElementById('totalInterestValue'),
    // totalCostValue removed - field no longer exists
    aprValue: document.getElementById('aprValue'),
    amortizationBody: document.getElementById('amortizationBody'),

    // Export/Share dropdown
    shareDropdownBtn: document.getElementById('shareDropdownBtn'),
    shareDropdownMenu: document.getElementById('shareDropdownMenu'),
    copyImageBtn: document.getElementById('copyImageBtn'),
    copyTextBtn: document.getElementById('copyTextBtn'),
    exportCSV: document.getElementById('exportCSV'),
    exportExcel: document.getElementById('exportExcel'),
    exportPDF: document.getElementById('exportPDF'),
    saveImageBtn: document.getElementById('saveImageBtn'),

    // Chart magnify
    magnifyPaymentChart: document.getElementById('magnifyPaymentChart'),
    magnifyBalanceChart: document.getElementById('magnifyBalanceChart'),

    // Modal
    chartModal: document.getElementById('chartModal'),
    modalTitle: document.getElementById('modalTitle'),
    modalClose: document.getElementById('modalClose'),
    periodSlider: document.getElementById('periodSlider'),
    periodDisplay: document.getElementById('periodDisplay'),
    periodDetails: document.getElementById('periodDetails'),

    // Settings dropdown
    settingsToggle: document.getElementById('settingsToggle'),
    settingsMenu: document.getElementById('settingsMenu'),

    // Grace payment toggle
    graceToggleContainer: document.getElementById('graceToggleContainer'),
    gracePaymentToggle: document.getElementById('gracePaymentToggle'),
    gracePaymentValue: document.getElementById('gracePaymentValue'),

    // Details toggle
    detailsToggle: document.getElementById('detailsToggle'),
    detailsToggleIcon: document.getElementById('detailsToggleIcon'),
    detailsContainer: document.getElementById('detailsContainer'),

    // Fullscreen modal
    fullscreenModal: document.getElementById('fullscreenModal'),
    fullscreenTitle: document.getElementById('fullscreenTitle'),
    fullscreenBody: document.getElementById('fullscreenBody'),
    fullscreenClose: document.getElementById('fullscreenClose')
};

// Initialize application
function init() {
    // Load saved preferences
    loadPreferences();

    // Set up event listeners
    setupEventListeners();

    // Initialize UI
    i18n.updateUI();
    i18n.updateCurrencyUI();

    // Update monthly payment label based on payment method
    updateMonthlyPaymentLabel();
}

// Load saved preferences from localStorage (or chrome.storage)
function loadPreferences() {
    const savedLang = localStorage.getItem('loanCalc_language');
    const savedTheme = localStorage.getItem('loanCalc_theme');
    const savedCurrency = localStorage.getItem('loanCalc_currency');
    const savedFontSize = localStorage.getItem('loanCalc_fontSize');

    if (savedLang) {
        elements.languageSelect.value = savedLang;
        i18n.setLanguage(savedLang);
    }

    if (savedTheme) {
        currentThemeIndex = themes.indexOf(savedTheme);
        if (currentThemeIndex === -1) currentThemeIndex = 0;
        setTheme(savedTheme);
    }

    if (savedCurrency) {
        elements.currencySelect.value = savedCurrency;
        i18n.setCurrency(savedCurrency);
    }

    if (savedFontSize) {
        elements.fontSizeSelect.value = savedFontSize;
        setFontSize(savedFontSize);
    } else {
        setFontSize('small');
    }
}

// Set up all event listeners
function setupEventListeners() {
    // Language change
    elements.languageSelect.addEventListener('change', (e) => {
        const lang = e.target.value;
        i18n.setLanguage(lang);
        i18n.updateCurrencyUI();
        localStorage.setItem('loanCalc_language', lang);

        // Update charts if they exist
        if (currentResults) {
            updateCharts(currentResults);
        }

        updateMonthlyPaymentLabel();
    });

    // Theme toggle
    elements.themeToggle.addEventListener('click', () => {
        currentThemeIndex = (currentThemeIndex + 1) % themes.length;
        const theme = themes[currentThemeIndex];

        elements.themeToggle.classList.add('switching');
        setTimeout(() => {
            elements.themeToggle.classList.remove('switching');
        }, 400);

        setTheme(theme);
        localStorage.setItem('loanCalc_theme', theme);
    });

    // Currency change
    elements.currencySelect.addEventListener('change', (e) => {
        const currency = e.target.value;
        i18n.setCurrency(currency);
        localStorage.setItem('loanCalc_currency', currency);

        if (currentResults) {
            displayResults(currentResults);
        }
    });

    // Font size change
    if (elements.fontSizeSelect) {
        elements.fontSizeSelect.addEventListener('change', (e) => {
            const fontSize = e.target.value;
            setFontSize(fontSize);
            localStorage.setItem('loanCalc_fontSize', fontSize);
        });
    }

    // Loan type change
    elements.loanTypeSelect.addEventListener('change', (e) => {
        const loanType = e.target.value;

        if (loanType === 'other') {
            elements.customLoanType.classList.remove('hidden');
            elements.customLoanType.focus();
        } else {
            elements.customLoanType.classList.add('hidden');
        }

        if (defaultLoanTerms[loanType]) {
            elements.loanTerm.value = defaultLoanTerms[loanType];
        }

        if (defaultLoanRatios[loanType]) {
            elements.loanRatio.value = defaultLoanRatios[loanType];
        }
    });

    // Grace period toggle
    if (elements.gracePeriodToggle) {
        elements.gracePeriodToggle.addEventListener('change', (e) => {
            if (e.target.checked) {
                elements.gracePeriodInputs.classList.add('active');
            } else {
                elements.gracePeriodInputs.classList.remove('active');
            }
        });
    }

    // Details toggle (show/hide total payment & interest)
    if (elements.detailsToggle) {
        elements.detailsToggle.addEventListener('click', () => {
            const container = elements.detailsContainer;
            const icon = elements.detailsToggleIcon;
            if (container.style.display === 'none') {
                container.style.display = 'grid';
                icon.textContent = '−';
            } else {
                container.style.display = 'none';
                icon.textContent = '+';
            }
        });
    }

    // Share dropdown toggle
    if (elements.shareDropdownBtn) {
        elements.shareDropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = elements.shareDropdownBtn.parentElement;
            dropdown.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
            const dropdown = elements.shareDropdownBtn.parentElement;
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    }

    // Chart magnify buttons
    if (elements.magnifyPaymentChart) {
        elements.magnifyPaymentChart.addEventListener('click', () => {
            openChartModal('payment');
        });
    }

    if (elements.magnifyBalanceChart) {
        elements.magnifyBalanceChart.addEventListener('click', () => {
            openChartModal('balance');
        });
    }

    // Modal close
    if (elements.modalClose) {
        elements.modalClose.addEventListener('click', closeChartModal);
    }

    if (elements.chartModal) {
        elements.chartModal.addEventListener('click', (e) => {
            if (e.target === elements.chartModal) {
                closeChartModal();
            }
        });
    }

    // Period slider
    if (elements.periodSlider) {
        elements.periodSlider.addEventListener('input', (e) => {
            const period = parseInt(e.target.value);
            elements.periodDisplay.textContent = period;
            updatePeriodDetails(period);
        });
    }

    // Settings dropdown toggle
    if (elements.settingsToggle) {
        elements.settingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = elements.settingsToggle.parentElement;
            dropdown.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
            const dropdown = elements.settingsToggle.parentElement;
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    }

    // Grace payment toggle
    if (elements.gracePaymentToggle) {
        elements.gracePaymentToggle.addEventListener('change', (e) => {
            updateGracePaymentDisplay();
        });
    }

    // Fullscreen buttons
    document.querySelectorAll('.btn-fullscreen').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.target;
            openFullscreen(target);
        });
    });

    // Fullscreen close
    if (elements.fullscreenClose) {
        elements.fullscreenClose.addEventListener('click', closeFullscreen);
    }

    if (elements.fullscreenModal) {
        elements.fullscreenModal.addEventListener('click', (e) => {
            if (e.target === elements.fullscreenModal) {
                closeFullscreen();
            }
        });
    }

    // Payment method change
    elements.paymentMethod.addEventListener('change', () => {
        updateMonthlyPaymentLabel();
    });

    // Add cost button
    elements.addCostBtn.addEventListener('click', addCostItem);

    // Reset button
    if (elements.resetBtn) {
        elements.resetBtn.addEventListener('click', resetForm);
    }

    // Custom spinner buttons
    document.querySelectorAll('.custom-spinner button').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetId = btn.getAttribute('data-target');
            const input = document.getElementById(targetId);
            if (!input) return;

            const step = parseFloat(input.step) || 1;
            const min = parseFloat(input.min) || 0;
            const max = parseFloat(input.max) || Infinity;
            let value = parseFloat(input.value) || 0;

            if (btn.classList.contains('spin-up')) {
                value = Math.min(max, value + step);
            } else {
                value = Math.max(min, value - step);
            }

            // Format based on step (handle decimals)
            if (step < 1) {
                const decimals = step.toString().split('.')[1]?.length || 2;
                input.value = value.toFixed(decimals);
            } else {
                input.value = value;
            }

            // Trigger input event for any listeners
            input.dispatchEvent(new Event('input', { bubbles: true }));
        });
    });

    // Calculate button
    elements.calculateBtn.addEventListener('click', calculate);

    // Export buttons
    elements.copyImageBtn.addEventListener('click', copyImageToClipboard);
    elements.copyTextBtn.addEventListener('click', copyResultText);
    elements.exportCSV.addEventListener('click', exportToCSV);
    elements.exportExcel.addEventListener('click', exportToExcel);
    elements.exportPDF.addEventListener('click', exportToPDF);
    elements.saveImageBtn.addEventListener('click', saveScreenshot);

    // Enter key to calculate
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') {
            calculate();
        }
    });

    // Add thousand separator formatting to amount input
    if (elements.loanAmount) {
        elements.loanAmount.addEventListener('input', (e) => {
            formatNumberInput(e.target);
        });

        elements.loanAmount.addEventListener('blur', (e) => {
            const value = parseFormattedNumber(e.target.value);
            if (value > 0) {
                e.target.value = formatWithThousandSeparator(value);
            }
        });

        elements.loanAmount.addEventListener('focus', (e) => {
            e.target.value = parseFormattedNumber(e.target.value).toString();
        });
    }

    // Format existing value if present
    if (elements.loanAmount && elements.loanAmount.value) {
        const value = parseFormattedNumber(elements.loanAmount.value);
        if (value > 0) {
            elements.loanAmount.value = formatWithThousandSeparator(value);
        }
    }
}

// Set theme
function setTheme(theme) {
    // Preserve font size class
    const fontSizeClass = document.body.className.match(/font-\w+/)?.[0] || 'font-medium';
    document.body.className = `theme-${theme} ${fontSizeClass}`;

    if (elements.themeIcon) {
        elements.themeIcon.textContent = themeIcons[theme];
    }

    if (elements.themeToggle) {
        const titles = {
            light: i18n.t('themeLight'),
            dark: i18n.t('themeDark'),
            night: i18n.t('themeNight')
        };
        elements.themeToggle.title = titles[theme] || theme;
    }

    if (paymentChart || balanceChart) {
        updateChartsTheme();
    }
}

// Set font size
function setFontSize(size) {
    // Preserve theme class
    const themeClass = document.body.className.match(/theme-\w+/)?.[0] || 'theme-light';
    document.body.className = `${themeClass} font-${size}`;
}

// Get current theme colors
function getThemeColors() {
    const style = getComputedStyle(document.body);
    return {
        accent: style.getPropertyValue('--accent-color').trim(),
        success: style.getPropertyValue('--success-color').trim(),
        warning: style.getPropertyValue('--warning-color').trim(),
        text: style.getPropertyValue('--text-primary').trim(),
        textMuted: style.getPropertyValue('--text-muted').trim(),
        grid: style.getPropertyValue('--chart-grid').trim(),
        bg: style.getPropertyValue('--bg-card').trim()
    };
}

// Update monthly payment label based on payment method
function updateMonthlyPaymentLabel() {
    const label = document.querySelector('.card h3[data-i18n="monthlyPayment"]');
    if (label) {
        const hasGrace = parseInt(elements.gracePeriod?.value || 0) > 0;
        const isEqualPrincipal = elements.paymentMethod.value === 'equalPrincipal';

        if (hasGrace || isEqualPrincipal) {
            label.setAttribute('data-i18n', 'monthlyPaymentRange');
            label.textContent = i18n.t('monthlyPaymentRange');
        } else {
            label.setAttribute('data-i18n', 'monthlyPayment');
            label.textContent = i18n.t('monthlyPayment');
        }
    }
}

// Add cost item
function addCostItem() {
    const costItem = document.createElement('div');
    costItem.className = 'cost-item';
    costItem.innerHTML = `
        <input type="text" class="cost-name" placeholder="${i18n.t('costNamePlaceholder')}">
        <input type="number" class="cost-amount" placeholder="${i18n.t('costAmountPlaceholder')}" min="0" step="100">
        <button type="button" class="btn-remove" onclick="removeCostItem(this)">&times;</button>
    `;

    elements.costsContainer.appendChild(costItem);

    const amountInput = costItem.querySelector('.cost-amount');
    amountInput.addEventListener('input', updateTotalCosts);

    costItem.querySelector('.cost-name').focus();
}

// Remove cost item
function removeCostItem(button) {
    const costItem = button.parentElement;
    costItem.style.animation = 'slideIn 0.3s ease reverse';
    setTimeout(() => {
        costItem.remove();
        updateTotalCosts();
    }, 280);
}

// Update total additional costs display
function updateTotalCosts() {
    const costs = getAdditionalCosts();
    const total = costs.reduce((sum, cost) => sum + cost.amount, 0);
    elements.totalCostsValue.textContent = i18n.formatCurrency(total);
}

// Get additional costs from inputs
function getAdditionalCosts() {
    const costItems = elements.costsContainer.querySelectorAll('.cost-item');
    const costs = [];

    costItems.forEach(item => {
        const name = item.querySelector('.cost-name').value.trim();
        const amount = parseFloat(item.querySelector('.cost-amount').value) || 0;

        if (name && amount > 0) {
            costs.push({ name, amount });
        }
    });

    return costs;
}

// Get grace period in months
function getGracePeriodMonths() {
    if (!elements.gracePeriodToggle?.checked) {
        return 0;
    }

    const value = parseInt(elements.gracePeriod?.value || 0);
    const unit = elements.gracePeriodUnit?.value || 'years';

    return unit === 'years' ? value * 12 : value;
}

// Validate inputs
function validateInputs() {
    const amount = parseFormattedNumber(elements.loanAmount.value);
    const term = parseFloat(elements.loanTerm.value);
    const rate = parseFloat(elements.interestRate.value);
    const gracePeriod = getGracePeriodMonths();
    const totalMonths = term * 12;

    if (!amount || amount <= 0) {
        alert(i18n.t('alertInvalidAmount'));
        elements.loanAmount.focus();
        return false;
    }

    if (!term || term <= 0) {
        alert(i18n.t('alertInvalidTerm'));
        elements.loanTerm.focus();
        return false;
    }

    if (rate < 0) {
        alert(i18n.t('alertInvalidRate'));
        elements.interestRate.focus();
        return false;
    }

    if (gracePeriod >= totalMonths) {
        alert(i18n.t('alertInvalidGrace'));
        elements.gracePeriod.focus();
        return false;
    }

    return true;
}

// Format number with thousand separator
function formatWithThousandSeparator(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Parse formatted number (remove commas)
function parseFormattedNumber(value) {
    if (typeof value === 'number') return value;
    const cleaned = value.toString().replace(/,/g, '');
    return parseFloat(cleaned) || 0;
}

// Format number input with thousand separators while typing
function formatNumberInput(input) {
    const cursorPos = input.selectionStart;
    const oldValue = input.value;
    const oldLength = oldValue.length;

    let cleaned = oldValue.replace(/[^\d.]/g, '');

    const parts = cleaned.split('.');
    const integerPart = parts[0];
    const decimalPart = parts.length > 1 ? parts[1] : '';

    const formatted = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    const newValue = decimalPart ? `${formatted}.${decimalPart}` : formatted;

    input.value = newValue;

    const newLength = newValue.length;
    const diff = newLength - oldLength;
    const newCursorPos = cursorPos + diff;

    input.setSelectionRange(newCursorPos, newCursorPos);
}

// Reset form to default values
function resetForm() {
    // Add spinning animation
    if (elements.resetBtn) {
        elements.resetBtn.classList.add('spinning');
        setTimeout(() => {
            elements.resetBtn.classList.remove('spinning');
        }, 500);
    }

    // Reset loan type
    elements.loanTypeSelect.value = 'mortgage';
    elements.customLoanType.classList.add('hidden');
    elements.customLoanType.value = '';

    // Reset loan amount
    elements.loanAmount.value = formatWithThousandSeparator(10000000);

    // Reset loan ratio
    elements.loanRatio.value = defaultLoanRatios['mortgage'];

    // Reset loan term
    elements.loanTerm.value = defaultLoanTerms['mortgage'];

    // Reset interest rate
    elements.interestRate.value = '2.5';

    // Reset grace period
    if (elements.gracePeriodToggle) {
        elements.gracePeriodToggle.checked = false;
        elements.gracePeriodInputs.classList.remove('active');
    }
    if (elements.gracePeriod) {
        elements.gracePeriod.value = '1';
    }
    if (elements.gracePeriodUnit) {
        elements.gracePeriodUnit.value = 'years';
    }

    // Reset payment method
    elements.paymentMethod.value = 'equalPayment';

    // Clear additional costs
    elements.costsContainer.innerHTML = '';
    elements.totalCostsValue.textContent = '0';

    // Hide results section
    elements.resultsSection.style.display = 'none';

    // Reset charts
    if (paymentChart) {
        paymentChart.destroy();
        paymentChart = null;
    }
    if (balanceChart) {
        balanceChart.destroy();
        balanceChart = null;
    }

    // Clear current results
    currentResults = null;
    currentSummary = null;

    // Update monthly payment label
    updateMonthlyPaymentLabel();
}

// Main calculation function
function calculate() {
    if (!validateInputs()) return;

    const amount = parseFormattedNumber(elements.loanAmount.value);
    const ratio = parseFloat(elements.loanRatio.value) || 100;
    const rate = parseFloat(elements.interestRate.value);
    const term = parseFloat(elements.loanTerm.value);
    const gracePeriod = getGracePeriodMonths();
    const method = elements.paymentMethod.value;
    const costs = getAdditionalCosts();

    calculator.setParams(amount, ratio, rate, term, gracePeriod, method);
    calculator.setAdditionalCosts(costs);

    currentResults = calculator.calculate();
    currentSummary = calculator.getSummary();

    displayResults(currentResults);
    updateCharts(currentResults);
    populateTable(currentResults.schedule);
    updateMonthlyPaymentLabel();

    elements.resultsSection.style.display = 'block';
    elements.resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Display calculation results
function displayResults(results) {
    const hasGracePeriod = results.graceMonths > 0;

    if (hasGracePeriod) {
        elements.graceToggleContainer.style.display = 'block';
        elements.monthlyPaymentValue.style.display = 'none';

        elements.graceToggleContainer.dataset.gracePayment = results.monthlyPaymentFirst;
        elements.graceToggleContainer.dataset.postGracePayment = results.monthlyPaymentLast;

        updateGracePaymentDisplay();
    } else {
        elements.graceToggleContainer.style.display = 'none';
        elements.monthlyPaymentValue.style.display = 'block';

        if (results.monthlyPayment !== null) {
            elements.monthlyPaymentValue.textContent = i18n.formatCurrency(results.monthlyPayment);
        } else {
            elements.monthlyPaymentValue.textContent =
                `${i18n.formatCurrency(results.monthlyPaymentFirst)} ~ ${i18n.formatCurrency(results.monthlyPaymentLast)}`;
        }
    }

    elements.totalPaymentValue.textContent = i18n.formatCurrency(results.totalPayment);
    elements.totalInterestValue.textContent = i18n.formatCurrency(results.totalInterest);
    // totalCostValue removed - field no longer exists

    if (elements.aprValue) {
        elements.aprValue.textContent = i18n.formatPercent(results.apr);
    }
}

// Update grace payment display based on toggle state
function updateGracePaymentDisplay() {
    if (!elements.graceToggleContainer || !elements.gracePaymentValue) return;

    const isPostGrace = elements.gracePaymentToggle?.checked;
    const gracePayment = parseFloat(elements.graceToggleContainer.dataset.gracePayment) || 0;
    const postGracePayment = parseFloat(elements.graceToggleContainer.dataset.postGracePayment) || 0;

    const displayValue = isPostGrace ? postGracePayment : gracePayment;
    elements.gracePaymentValue.textContent = i18n.formatCurrency(displayValue);
}

// Update charts
function updateCharts(results) {
    const chartData = calculator.getChartData();
    const colors = getThemeColors();

    // Payment trend chart
    const paymentCtx = document.getElementById('paymentChart').getContext('2d');

    if (paymentChart) {
        paymentChart.destroy();
    }

    paymentChart = new Chart(paymentCtx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [{
                label: i18n.t('paymentAmount'),
                data: chartData.payments,
                borderColor: colors.accent,
                backgroundColor: colors.accent + '20',
                fill: true,
                tension: 0.4,
                pointRadius: chartData.labels.length > 60 ? 0 : 2,
                pointHoverRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            return `${context.dataset.label}: ${i18n.formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: false
                    },
                    ticks: { color: colors.textMuted, font: { size: 9 } },
                    grid: { color: colors.grid }
                },
                y: {
                    title: {
                        display: false
                    },
                    ticks: {
                        color: colors.textMuted,
                        font: { size: 9 },
                        callback: (value) => i18n.formatNumber(value)
                    },
                    grid: { color: colors.grid }
                }
            }
        }
    });

    // Balance chart
    const balanceCtx = document.getElementById('balanceChart').getContext('2d');

    if (balanceChart) {
        balanceChart.destroy();
    }

    balanceChart = new Chart(balanceCtx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label: i18n.t('principalPaid'),
                    data: chartData.cumulativePrincipal,
                    borderColor: colors.success,
                    backgroundColor: colors.success + '20',
                    fill: true,
                    tension: 0.4,
                    pointRadius: chartData.labels.length > 60 ? 0 : 2,
                    pointHoverRadius: 4
                },
                {
                    label: i18n.t('interestPaid'),
                    data: chartData.cumulativeInterest,
                    borderColor: colors.warning,
                    backgroundColor: colors.warning + '20',
                    fill: true,
                    tension: 0.4,
                    pointRadius: chartData.labels.length > 60 ? 0 : 2,
                    pointHoverRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        color: colors.text,
                        font: { size: 8 },
                        boxWidth: 12,
                        padding: 8
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            return `${context.dataset.label}: ${i18n.formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: { display: false },
                    ticks: { color: colors.textMuted, font: { size: 9 } },
                    grid: { color: colors.grid }
                },
                y: {
                    title: { display: false },
                    ticks: {
                        color: colors.textMuted,
                        font: { size: 9 },
                        callback: (value) => i18n.formatNumber(value)
                    },
                    grid: { color: colors.grid }
                }
            }
        }
    });
}

// Update charts theme
function updateChartsTheme() {
    if (currentResults) {
        updateCharts(currentResults);
    }
}

// Populate amortization table
function populateTable(schedule) {
    elements.amortizationBody.innerHTML = '';

    schedule.forEach(entry => {
        const row = document.createElement('tr');
        if (entry.isGracePeriod) {
            row.className = 'grace-period';
        }
        row.innerHTML = `
            <td>${entry.period}${entry.isGracePeriod ? ' ' + i18n.t('graceLabel') : ''}</td>
            <td>${i18n.formatCurrency(entry.payment)}</td>
            <td>${i18n.formatCurrency(entry.principal)}</td>
            <td>${i18n.formatCurrency(entry.interest)}</td>
            <td>${i18n.formatCurrency(entry.cumulativePrincipal)}</td>
            <td>${i18n.formatCurrency(entry.cumulativeInterest)}</td>
            <td>${i18n.formatCurrency(entry.remainingBalance)}</td>
        `;
        elements.amortizationBody.appendChild(row);
    });
}

// Export to CSV
function exportToCSV() {
    if (!currentResults) return;

    const filename = `loan_schedule_${new Date().toISOString().slice(0, 10)}.csv`;
    downloadCSV(currentResults.schedule, i18n, filename);
}

// Export to Excel
function exportToExcel() {
    if (!currentResults || !currentSummary) return;

    const filename = `loan_schedule_${new Date().toISOString().slice(0, 10)}.xlsx`;
    downloadExcel(currentResults.schedule, currentSummary, i18n, filename);
}

// Export to PDF
function exportToPDF() {
    if (!currentResults || !currentSummary) return;

    const filename = `loan_schedule_${new Date().toISOString().slice(0, 10)}.pdf`;
    downloadPDF(currentResults.schedule, currentSummary, i18n, filename);
}

// Copy image to clipboard
async function copyImageToClipboard() {
    if (!currentSummary) return;

    try {
        const summaryCards = document.querySelector('.summary-cards');
        if (!summaryCards) return;

        const canvas = await html2canvas(summaryCards, {
            backgroundColor: getComputedStyle(document.body).getPropertyValue('--bg-primary'),
            scale: 2,
            logging: false,
            useCORS: true
        });

        // Convert canvas to blob
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));

        // Copy to clipboard
        await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob })
        ]);

        alert(i18n.t('alertExportSuccess'));
    } catch (err) {
        console.error('Copy image failed:', err);
        // Fallback: save as file
        saveScreenshot();
    }
}

// Save screenshot of results
async function saveScreenshot() {
    if (!currentSummary) return;

    try {
        const summaryCards = document.querySelector('.summary-cards');
        if (!summaryCards) return;

        const canvas = await html2canvas(summaryCards, {
            backgroundColor: getComputedStyle(document.body).getPropertyValue('--bg-primary'),
            scale: 2,
            logging: false,
            useCORS: true
        });

        const link = document.createElement('a');
        link.href = canvas.toDataURL('image/png');
        link.download = `loan-calculation-${new Date().toISOString().slice(0, 10)}.png`;
        link.click();
        alert(i18n.t('alertExportSuccess'));
    } catch (err) {
        console.error('Screenshot failed:', err);
    }
}

// Copy result text to clipboard
async function copyResultText() {
    if (!currentSummary) return;

    const text = `${i18n.t('shareTitle')}\n\n${generateShareText()}`;

    if (navigator.clipboard) {
        try {
            await navigator.clipboard.writeText(text);
            alert(i18n.t('alertExportSuccess'));
        } catch (err) {
            fallbackCopy(text);
        }
    } else {
        fallbackCopy(text);
    }
}

// Fallback copy function
function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    alert(i18n.t('alertExportSuccess'));
}

// Generate share text
function generateShareText() {
    const summary = currentSummary;
    const lines = [
        `${i18n.t('loanAmount')}: ${i18n.formatCurrency(summary.actualAmount)}`,
        `${i18n.t('interestRate')}: ${summary.annualRate}%`,
        `${i18n.t('loanTerm')}: ${summary.termYears} ${i18n.t('years')}`,
    ];

    if (summary.gracePeriodMonths > 0) {
        lines.push(`${i18n.t('gracePeriod')}: ${summary.gracePeriodMonths} ${i18n.t('months')}`);
    }

    lines.push('');
    lines.push(`${i18n.t('totalPayment')}: ${i18n.formatCurrency(summary.totalPayment)}`);
    lines.push(`${i18n.t('totalInterest')}: ${i18n.formatCurrency(summary.totalInterest)}`);
    lines.push(`${i18n.t('apr')}: ${summary.apr.toFixed(2)}%`);

    return lines.join('\n');
}

// Chart Modal Functions
function openChartModal(type) {
    if (!currentResults || !currentResults.schedule.length) return;

    const schedule = currentResults.schedule;
    const maxPeriod = schedule.length;

    elements.modalTitle.textContent = type === 'payment'
        ? i18n.t('paymentChart')
        : i18n.t('balanceChart');

    elements.periodSlider.max = maxPeriod;
    elements.periodSlider.value = 1;
    elements.periodDisplay.textContent = 1;

    updatePeriodDetails(1);

    elements.chartModal.classList.add('active');
}

function closeChartModal() {
    elements.chartModal.classList.remove('active');
}

// Fullscreen modal functions
let fullscreenChart = null;

function openFullscreen(target) {
    if (!elements.fullscreenModal) return;

    const body = elements.fullscreenBody;
    body.innerHTML = '';

    if (target === 'paymentChartFull') {
        elements.fullscreenTitle.textContent = i18n.t('paymentChart');
        const canvas = document.createElement('canvas');
        canvas.id = 'paymentChartFull';
        body.appendChild(canvas);

        // Create enlarged chart
        const ctx = canvas.getContext('2d');
        if (fullscreenChart) fullscreenChart.destroy();
        fullscreenChart = createPaymentChartCopy(ctx);

    } else if (target === 'balanceChartFull') {
        elements.fullscreenTitle.textContent = i18n.t('balanceChart');
        const canvas = document.createElement('canvas');
        canvas.id = 'balanceChartFull';
        body.appendChild(canvas);

        // Create enlarged chart
        const ctx = canvas.getContext('2d');
        if (fullscreenChart) fullscreenChart.destroy();
        fullscreenChart = createBalanceChartCopy(ctx);

    } else if (target === 'tableFull') {
        elements.fullscreenTitle.textContent = i18n.t('amortizationSchedule');
        const tableContainer = document.createElement('div');
        tableContainer.className = 'table-scroll';
        tableContainer.innerHTML = document.getElementById('amortizationTable').outerHTML;
        body.appendChild(tableContainer);
    }

    elements.fullscreenModal.classList.add('active');
}

function closeFullscreen() {
    if (!elements.fullscreenModal) return;
    elements.fullscreenModal.classList.remove('active');
    if (fullscreenChart) {
        fullscreenChart.destroy();
        fullscreenChart = null;
    }
}

function createPaymentChartCopy(ctx) {
    if (!currentResults) return null;

    const schedule = currentResults.schedule;
    const labels = schedule.map(item => item.period);
    const payments = schedule.map(item => item.payment);

    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: i18n.t('paymentAmount'),
                data: payments,
                borderColor: 'rgb(67, 97, 238)',
                backgroundColor: 'rgba(67, 97, 238, 0.1)',
                fill: true,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: value => i18n.formatCurrency(value)
                    }
                }
            }
        }
    });
}

function createBalanceChartCopy(ctx) {
    if (!currentResults) return null;

    const schedule = currentResults.schedule;
    const labels = schedule.map(item => item.period);
    const cumulativePrincipal = schedule.map(item => item.cumulativePrincipal);
    const cumulativeInterest = schedule.map(item => item.cumulativeInterest);

    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: i18n.t('principalPaid'),
                    data: cumulativePrincipal,
                    borderColor: 'rgb(16, 185, 129)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    fill: true,
                    tension: 0.1
                },
                {
                    label: i18n.t('interestPaid'),
                    data: cumulativeInterest,
                    borderColor: 'rgb(245, 158, 11)',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    fill: true,
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => i18n.formatCurrency(value)
                    }
                }
            }
        }
    });
}

function updatePeriodDetails(period) {
    if (!currentResults || !currentResults.schedule.length) return;

    const schedule = currentResults.schedule;
    const entry = schedule[period - 1];

    if (!entry) return;

    const isGrace = entry.isGracePeriod;
    const graceLabel = isGrace ? ` ${i18n.t('graceLabel')}` : '';

    elements.periodDetails.innerHTML = `
        <div class="detail-item highlight">
            <div class="label">${i18n.t('period')}</div>
            <div class="value">${entry.period}${graceLabel}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('payment')}</div>
            <div class="value">${i18n.formatCurrency(entry.payment)}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('principal')}</div>
            <div class="value">${i18n.formatCurrency(entry.principal)}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('interest')}</div>
            <div class="value">${i18n.formatCurrency(entry.interest)}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('cumulativePrincipal')}</div>
            <div class="value">${i18n.formatCurrency(entry.cumulativePrincipal)}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('cumulativeInterest')}</div>
            <div class="value">${i18n.formatCurrency(entry.cumulativeInterest)}</div>
        </div>
        <div class="detail-item">
            <div class="label">${i18n.t('remainingBalance')}</div>
            <div class="value">${i18n.formatCurrency(entry.remainingBalance)}</div>
        </div>
    `;
}

// Make removeCostItem available globally
window.removeCostItem = removeCostItem;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', init);
